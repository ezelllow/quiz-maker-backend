window.PACKET = {
  "paper": {
    "title": "demo-physics-paper",
    "source_pdf": "source.pdf",
    "check_version": "1.0",
    "ai_pass_done": false
  },
  "source_pages": [
    "source_pages/page-1.png",
    "source_pages/page-2.png"
  ],
  "questions": [
    {
      "qno": "1",
      "subject": "Physics",
      "subtopic": "Kinematics",
      "text": "A car accelerates uniformly from rest to 24 m/s in 8.0 s. Calculate the acceleration of the car.",
      "answer": "3.0 m/s^2",
      "image": "",
      "page": "1",
      "marks": "",
      "images": [],
      "checks": [
        {
          "id": "missing-field",
          "status": "pass",
          "note": "all required fields present"
        },
        {
          "id": "ocr-artifacts",
          "status": "pass",
          "note": "no OCR artifacts detected"
        },
        {
          "id": "image-missing",
          "status": "pass",
          "note": "no image referenced"
        },
        {
          "id": "length-outlier",
          "status": "pass",
          "note": "length within normal range"
        },
        {
          "id": "qno-sequence",
          "status": "warn",
          "note": "missing question number(s): 3"
        },
        {
          "id": "duplicate",
          "status": "warn",
          "note": "≈ Q5 in this paper"
        }
      ],
      "auto_verdict": "warn"
    },
    {
      "qno": "2",
      "subject": "Physics",
      "subtopic": "Forces",
      "text": "The diagram shows a spring stretched by a load of 25 N. Determine the extension using the",
      "answer": "",
      "image": "q2_graph.png",
      "page": "1",
      "marks": "",
      "images": [
        {
          "name": "q2_graph.png",
          "path": "images/q2_graph.png",
          "exists": true
        }
      ],
      "checks": [
        {
          "id": "missing-field",
          "status": "pass",
          "note": "all required fields present"
        },
        {
          "id": "ocr-artifacts",
          "status": "warn",
          "note": "text ends mid-sentence — possibly truncated"
        },
        {
          "id": "image-missing",
          "status": "pass",
          "note": "1 image(s) found"
        },
        {
          "id": "length-outlier",
          "status": "pass",
          "note": "length within normal range"
        },
        {
          "id": "image-degenerate",
          "status": "pass",
          "note": "image file sizes look sane"
        },
        {
          "id": "duplicate",
          "status": "pass",
          "note": "no near-duplicates found"
        }
      ],
      "auto_verdict": "warn"
    },
    {
      "qno": "4",
      "subject": "Physics",
      "subtopic": "Kinematics",
      "text": "A ball is dropped from a height of 45 m. Taking g = 10 m/s?? calculate the time taken to reach the ground.",
      "answer": "3.0 s",
      "image": "q4_tiny.png; q4_missing.png",
      "page": "2",
      "marks": "",
      "images": [
        {
          "name": "q4_tiny.png",
          "path": "images/q4_tiny.png",
          "exists": true
        },
        {
          "name": "q4_missing.png",
          "path": "images/q4_missing.png",
          "exists": false
        }
      ],
      "checks": [
        {
          "id": "missing-field",
          "status": "pass",
          "note": "all required fields present"
        },
        {
          "id": "ocr-artifacts",
          "status": "warn",
          "note": "multiple '?' — likely unrecognised symbol"
        },
        {
          "id": "image-missing",
          "status": "fail",
          "note": "not found on disk: q4_missing.png"
        },
        {
          "id": "length-outlier",
          "status": "pass",
          "note": "length within normal range"
        },
        {
          "id": "image-degenerate",
          "status": "warn",
          "note": "q4_tiny.png is only 78 bytes — possibly a blank or bad crop"
        },
        {
          "id": "duplicate",
          "status": "pass",
          "note": "no near-duplicates found"
        }
      ],
      "auto_verdict": "fail"
    },
    {
      "qno": "5",
      "subject": "Physics",
      "subtopic": "Kinematics",
      "text": "A car accelerates uniformly from rest to 24 m/s in 8.0 s. Calculate the acceleration of this car.",
      "answer": "",
      "image": "",
      "page": "2",
      "marks": "",
      "images": [],
      "checks": [
        {
          "id": "missing-field",
          "status": "pass",
          "note": "all required fields present"
        },
        {
          "id": "ocr-artifacts",
          "status": "pass",
          "note": "no OCR artifacts detected"
        },
        {
          "id": "image-missing",
          "status": "pass",
          "note": "no image referenced"
        },
        {
          "id": "length-outlier",
          "status": "pass",
          "note": "length within normal range"
        },
        {
          "id": "duplicate",
          "status": "warn",
          "note": "≈ Q1 in this paper"
        }
      ],
      "auto_verdict": "warn"
    }
  ]
};
