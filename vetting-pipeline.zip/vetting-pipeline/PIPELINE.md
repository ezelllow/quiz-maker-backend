# quizMaker Vetting Pipeline

Goal: you stay the final approver, but stop doing the tedious comparison work.
The machine pre-vets everything; you spend seconds on clean questions and real
attention only on flagged ones.

## The flow (per paper)

```
 source PDF
     │
 1. EXTRACT        ocr (Sharingan) skill — unchanged
     │             → Excel catalogue + redrawn/cropped PNGs
     ▼
 2. AUTO-CHECK     make_packet.py  (deterministic checks, instant)
     │             + AI fidelity pass (Claude re-reads each source page and
     │               diffs it against the extraction — absorbed from your
     │               check skill, improved)
     │             → packet.js + reviewer.html in a per-paper folder
     ▼
 3. HUMAN VET      open reviewer.html — side-by-side source page vs extraction,
     │             every check result visible, keyboard-driven:
     │             A approve · F flag · E edit-note · J/K next/prev
     │             Green (all checks passed) questions: skim & approve in ~3s.
     │             Red/amber: the reasons are already written out for you.
     │             → decisions.json (exported from the UI)
     ▼
 4. COMMIT         commit script / Claude applies decisions:
                   approved rows → Google Sheet bank, with vet_status,
                   vetted_by, vetted_at, check_version columns
                   flagged rows → back to fix queue
```

## Why this shape

- **Human accuracy is preserved**: nothing enters the bank without your click.
  The pipeline never auto-approves; it only pre-sorts and pre-explains.
- **Load drops** because the two expensive things you do today — flipping
  between Drive/Sheets/PDF to compare, and re-running your check skill then
  reconciling its output — are collapsed into one screen where everything is
  already side-by-side and pre-checked.
- **Trust but verify the AI check**: the AI pass is a *first reader*, not a
  gatekeeper. Its verdicts are displayed, never enforced. Over time you can
  batch-approve green questions with more confidence as you calibrate how
  often the AI pass misses (the decisions log lets you measure exactly that).

## Per-paper folder convention

```
papers/
  2026-07-P4-physics-prelim/
    source.pdf              ← the original paper
    extraction.xlsx         ← ocr skill output
    images/                 ← ocr skill PNGs (redrawn diagrams / crops)
    source_pages/           ← page-N.png snapshots (make_packet.py renders these)
    packet.js               ← all question data + check results (generated)
    reviewer.html           ← the vetting UI (copied in by make_packet.py)
    decisions.json          ← your verdicts (exported from reviewer)
```

## Check catalogue

Deterministic (run by make_packet.py, free and instant):

| id              | what it catches                                              |
|-----------------|--------------------------------------------------------------|
| missing-field   | empty question text / subject / subtopic / question number   |
| qno-sequence    | gaps or duplicates in question numbering                     |
| ocr-artifacts   | `??`, replacement chars, broken math (`x^ 2`), cut-off text  |
| image-missing   | catalogue references an image that doesn't exist on disk     |
| image-degenerate| image file is tiny/blank (likely a bad crop)                 |
| length-outlier  | question text suspiciously short or long vs the paper's norm |
| duplicate       | fuzzy match against other questions in this paper (and       |
|                 | optionally against a bank export CSV)                        |

AI fidelity pass (run by Claude via the vetting skill — this is where your
check skill's rules get absorbed):

| id              | what it checks                                               |
|-----------------|--------------------------------------------------------------|
| text-fidelity   | extracted text vs the actual source page: numbers, units,    |
|                 | symbols, sub-parts, options — word-level diff                |
| crop-quality    | cropped/redrawn image contains the *full* diagram, no cut    |
|                 | labels, no neighbouring-question bleed                       |
| completeness    | nothing from the question missed (tables, mark allocations,  |
|                 | answer lines that carry data)                                |
| <your rules>    | whatever your current check skill enforces — to be folded in |

Each check yields pass / warn / fail + a one-line reason, stored per question
in packet.js, so the reviewer can sort worst-first.

## Weekly workflow (a few papers/week)

1. Drop the paper PDF in a new folder under `papers/`.
2. Tell Claude: "vet this paper" → skill runs extract (if not done),
   auto-checks, AI pass, builds the reviewer.
3. Open reviewer.html, work through it (worst-first ordering), export
   decisions.json.
4. Tell Claude: "commit the decisions" → approved rows land in the Sheet
   with vet metadata; flagged ones come back to you as a fix list.

## Commit stage notes

Your repo already has Google Sheets credentials (`credentials.json`) and
sheet tooling (`auto_categorize_sheet.py`, `quiz_backend.py`). The commit
script reuses those. Recommended new columns on the bank sheet:
`vet_status` (approved/flagged), `vetted_by`, `vetted_at`, `check_version`,
`source_paper`. That gives you an audit trail and lets you re-vet after any
check improvement by filtering on `check_version`.
