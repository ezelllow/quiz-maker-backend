#!/usr/bin/env python3
"""
make_packet.py — build a vetting packet from an OCR extraction.

Takes a per-paper folder containing:
    source.pdf          the original paper (optional but recommended)
    extraction.xlsx     OCR catalogue (columns: Question No, Subtopic, Subject,
                        Question text; extra columns like Answer, Image, Page
                        are picked up automatically if present)
    images/             extracted/redrawn PNGs (matched to questions by
                        an Image column, or by qno appearing in the filename)

Produces, in the same folder:
    source_pages/page-N.png   rendered PDF pages (for side-by-side review)
    packet.js                 window.PACKET = {...} consumed by reviewer.html
    reviewer.html              copied in from the pipeline directory

Usage:
    python3 make_packet.py papers/2026-07-P4-physics-prelim [--bank bank.csv]

The AI fidelity pass (text-fidelity / crop-quality / completeness) is added
afterwards by Claude via the vetting skill: it edits packet.js in place,
appending to each question's "checks" list. This script only runs the
deterministic checks.
"""

import argparse
import difflib
import json
import re
import shutil
import sys
import unicodedata
from pathlib import Path

CHECK_VERSION = "1.0"

# ---------------------------------------------------------------- extraction


def load_catalogue(xlsx_path: Path):
    """Read the OCR Excel catalogue into a list of dicts, tolerant of
    header naming variations."""
    import openpyxl

    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        sys.exit(f"{xlsx_path} is empty")

    headers = [str(h).strip().lower() if h is not None else "" for h in rows[0]]

    def col(*names):
        for n in names:
            for i, h in enumerate(headers):
                if n in h:
                    return i
        return None

    idx = {
        "qno": col("question no", "qn", "q no", "no."),
        "subtopic": col("subtopic", "sub-topic", "topic"),
        "subject": col("subject"),
        "text": col("question text", "question", "text"),
        "answer": col("answer", "solution"),
        "image": col("image", "diagram", "figure"),
        "page": col("page"),
        "marks": col("marks"),
    }
    if idx["text"] is None:
        sys.exit(f"Could not find a question-text column in {xlsx_path}; headers: {headers}")

    questions = []
    for r in rows[1:]:
        if r is None or all(v is None or str(v).strip() == "" for v in r):
            continue

        def get(key):
            i = idx.get(key)
            if i is None or i >= len(r) or r[i] is None:
                return ""
            return str(r[i]).strip()

        questions.append({
            "qno": get("qno"),
            "subject": get("subject"),
            "subtopic": get("subtopic"),
            "text": get("text"),
            "answer": get("answer"),
            "image": get("image"),
            "page": get("page"),
            "marks": get("marks"),
        })
    return questions


def match_images(questions, images_dir: Path):
    """Attach image paths: explicit Image column first, else filename
    containing the question number (q3, q03, Q3_, _3_diagram...)."""
    files = sorted(images_dir.glob("*.png")) + sorted(images_dir.glob("*.jpg")) if images_dir.is_dir() else []
    for q in questions:
        attached = []
        if q["image"]:
            for name in re.split(r"[;,]\s*", q["image"]):
                p = images_dir / name if not Path(name).is_absolute() else Path(name)
                attached.append({"name": name, "path": f"images/{p.name}", "exists": p.exists()})
        elif q["qno"]:
            qn = re.sub(r"\D", "", q["qno"])
            if qn:
                pat = re.compile(rf"(?:^|[^0-9])0*{qn}(?:[^0-9]|$)")
                for f in files:
                    if pat.search(f.stem.lower().replace("question", "q")):
                        attached.append({"name": f.name, "path": f"images/{f.name}", "exists": True})
        q["images"] = attached
    return questions


def render_source_pages(pdf_path: Path, out_dir: Path, dpi=150):
    """Render every PDF page to PNG for side-by-side review."""
    import fitz

    out_dir.mkdir(exist_ok=True)
    doc = fitz.open(pdf_path)
    pages = []
    for i, page in enumerate(doc, start=1):
        out = out_dir / f"page-{i}.png"
        if not out.exists():
            page.get_pixmap(dpi=dpi).save(out)
        pages.append(f"source_pages/{out.name}")
    doc.close()
    return pages


# ---------------------------------------------------------------- checks

ARTIFACT_PATTERNS = [
    (re.compile(r"\?{2,}"), "multiple '?' — likely unrecognised symbol"),
    (re.compile(r"[�]"), "unicode replacement character"),
    (re.compile(r"\b[a-zA-Z]\^\s+\d"), "broken superscript spacing"),
    (re.compile(r"(?:\bl\b\s*=|\bO\b\s*=)"), "possible l/1 or O/0 confusion in equation"),
    (re.compile(r"[|]{2,}"), "stray pipe characters"),
    (re.compile(r"\s{4,}"), "large internal whitespace run"),
]

TRUNCATION_RE = re.compile(r"(?:[,;:]|\b(?:the|a|an|of|to|is|are|and|or|with|which|that))\s*$", re.I)


def check_question(q, all_questions):
    checks = []

    def add(cid, status, note):
        checks.append({"id": cid, "status": status, "note": note})

    # missing-field
    missing = [f for f in ("qno", "subject", "subtopic", "text") if not q[f]]
    if missing:
        add("missing-field", "fail", f"empty: {', '.join(missing)}")
    else:
        add("missing-field", "pass", "all required fields present")

    # ocr-artifacts
    text = q["text"]
    hits = [note for pat, note in ARTIFACT_PATTERNS if pat.search(text)]
    if TRUNCATION_RE.search(text):
        hits.append("text ends mid-sentence — possibly truncated")
    if hits:
        add("ocr-artifacts", "warn", "; ".join(hits))
    else:
        add("ocr-artifacts", "pass", "no OCR artifacts detected")

    # image checks
    if q["images"]:
        missing_imgs = [im["name"] for im in q["images"] if not im["exists"]]
        if missing_imgs:
            add("image-missing", "fail", f"not found on disk: {', '.join(missing_imgs)}")
        else:
            add("image-missing", "pass", f"{len(q['images'])} image(s) found")
    else:
        add("image-missing", "pass", "no image referenced")

    # length-outlier
    lengths = [len(o["text"]) for o in all_questions if o["text"]]
    if lengths and text:
        med = sorted(lengths)[len(lengths) // 2]
        if len(text) < max(25, med * 0.15):
            add("length-outlier", "warn", f"very short ({len(text)} chars vs median {med}) — extraction may have missed content")
        elif len(text) > med * 6:
            add("length-outlier", "warn", f"very long ({len(text)} chars vs median {med}) — may contain a neighbouring question")
        else:
            add("length-outlier", "pass", "length within normal range")

    return checks


def normalise(s):
    s = unicodedata.normalize("NFKC", s.lower())
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", s)).strip()


def check_image_files(q, paper_dir: Path):
    """Flag tiny/blank image files (likely bad crops)."""
    out = []
    for im in q["images"]:
        if not im["exists"]:
            continue
        p = paper_dir / im["path"]
        size = p.stat().st_size
        if size < 2048:
            out.append({"id": "image-degenerate", "status": "warn",
                        "note": f"{im['name']} is only {size} bytes — possibly a blank or bad crop"})
    if q["images"] and not out:
        out.append({"id": "image-degenerate", "status": "pass", "note": "image file sizes look sane"})
    return out


def check_duplicates(questions, bank_texts):
    """Fuzzy duplicate detection within the paper and against a bank export."""
    norms = [(q, normalise(q["text"])) for q in questions]
    for i, (q, nq) in enumerate(norms):
        dup_notes = []
        if not nq:
            continue
        for j, (o, no) in enumerate(norms):
            if i == j or not no:
                continue
            if difflib.SequenceMatcher(None, nq, no).ratio() > 0.92:
                dup_notes.append(f"≈ Q{o['qno']} in this paper")
        for bank_qno, bt in bank_texts:
            if difflib.SequenceMatcher(None, nq, bt).ratio() > 0.92:
                dup_notes.append(f"≈ bank row {bank_qno}")
        if dup_notes:
            q["checks"].append({"id": "duplicate", "status": "warn", "note": "; ".join(sorted(set(dup_notes)))})
        else:
            q["checks"].append({"id": "duplicate", "status": "pass", "note": "no near-duplicates found"})


def check_qno_sequence(questions):
    nums = []
    for q in questions:
        m = re.search(r"\d+", q["qno"] or "")
        if m:
            nums.append((int(m.group()), q))
    seen = {}
    for n, q in nums:
        if n in seen:
            q["checks"].append({"id": "qno-sequence", "status": "warn", "note": f"question number {n} appears more than once"})
        seen.setdefault(n, q)
    if nums:
        expected = set(range(min(n for n, _ in nums), max(n for n, _ in nums) + 1))
        gaps = sorted(expected - set(n for n, _ in nums))
        if gaps:
            note = f"missing question number(s): {', '.join(map(str, gaps))}"
            nums[0][1]["checks"].append({"id": "qno-sequence", "status": "warn", "note": note})


# ---------------------------------------------------------------- main


def verdict(checks):
    statuses = [c["status"] for c in checks]
    if "fail" in statuses:
        return "fail"
    if "warn" in statuses:
        return "warn"
    return "pass"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paper_dir", type=Path, help="per-paper folder")
    ap.add_argument("--bank", type=Path, default=None,
                    help="optional CSV export of the existing bank (qno,text) for cross-paper duplicate checks")
    ap.add_argument("--xlsx", type=Path, default=None, help="override extraction file (default: extraction.xlsx)")
    ap.add_argument("--pdf", type=Path, default=None, help="override source PDF (default: source.pdf)")
    args = ap.parse_args()

    paper_dir = args.paper_dir.resolve()
    xlsx = args.xlsx or next(iter(sorted(paper_dir.glob("*.xlsx"))), None)
    if xlsx is None or not Path(xlsx).exists():
        sys.exit(f"No extraction .xlsx found in {paper_dir}")
    pdf = args.pdf or (paper_dir / "source.pdf")

    questions = load_catalogue(Path(xlsx))
    questions = match_images(questions, paper_dir / "images")

    pages = []
    if Path(pdf).exists():
        pages = render_source_pages(Path(pdf), paper_dir / "source_pages")
    else:
        print(f"note: no source PDF at {pdf} — reviewer will show extraction only", file=sys.stderr)

    # deterministic checks
    for q in questions:
        q["checks"] = check_question(q, questions)
        q["checks"] += check_image_files(q, paper_dir)
    check_qno_sequence(questions)

    bank_texts = []
    if args.bank and args.bank.exists():
        import csv
        with open(args.bank, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                t = normalise(row.get("text") or row.get("Question text") or "")
                if t:
                    bank_texts.append((row.get("qno") or row.get("Question No") or "?", t))
    check_duplicates(questions, bank_texts)

    for q in questions:
        q["auto_verdict"] = verdict(q["checks"])

    packet = {
        "paper": {
            "title": paper_dir.name,
            "source_pdf": Path(pdf).name if Path(pdf).exists() else None,
            "check_version": CHECK_VERSION,
            "ai_pass_done": False,
        },
        "source_pages": pages,
        "questions": questions,
    }

    out = paper_dir / "packet.js"
    out.write_text("window.PACKET = " + json.dumps(packet, indent=2, ensure_ascii=False) + ";\n",
                   encoding="utf-8")

    # copy the reviewer next to the packet so file:// relative paths work
    reviewer_src = Path(__file__).parent / "reviewer.html"
    if reviewer_src.exists():
        shutil.copy(reviewer_src, paper_dir / "reviewer.html")

    counts = {"pass": 0, "warn": 0, "fail": 0}
    for q in questions:
        counts[q["auto_verdict"]] += 1
    print(f"packet built: {out}")
    print(f"{len(questions)} questions — {counts['pass']} pass / {counts['warn']} warn / {counts['fail']} fail")
    print(f"open {paper_dir / 'reviewer.html'} to vet")


if __name__ == "__main__":
    main()
