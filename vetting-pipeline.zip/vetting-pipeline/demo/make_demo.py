"""Build a small fake extracted paper to exercise the pipeline."""
import fitz, openpyxl
from pathlib import Path
from PIL import Image, ImageDraw

paper = Path(__file__).parent / "papers" / "demo-physics-paper"
(paper / "images").mkdir(parents=True, exist_ok=True)

# --- fake source PDF (2 pages) ---
doc = fitz.open()
p1 = doc.new_page()
p1.insert_text((72, 90), "Demo Physics Paper — Sec 3 Express", fontsize=14)
p1.insert_text((72, 140), "1. A car accelerates uniformly from rest to 24 m/s in 8.0 s.", fontsize=11)
p1.insert_text((90, 158), "Calculate the acceleration of the car. [2]", fontsize=11)
p1.insert_text((72, 210), "2. The diagram shows a spring stretched by a load of 2.5 N.", fontsize=11)
p1.insert_text((90, 228), "Determine the extension using the graph. [3]", fontsize=11)
p2 = doc.new_page()
p2.insert_text((72, 90), "3. State Newton's first law of motion. [1]", fontsize=11)
p2.insert_text((72, 140), "4. A ball is dropped from a height of 45 m. Taking g = 10 m/s2,", fontsize=11)
p2.insert_text((90, 158), "calculate the time taken to reach the ground. [2]", fontsize=11)
doc.save(paper / "source.pdf"); doc.close()

# --- fake extracted images ---
img = Image.new("RGB", (400, 300), "white")
d = ImageDraw.Draw(img)
d.line([(50, 250), (350, 60)], fill="black", width=3)
d.line([(50, 250), (50, 40)], fill="black", width=2)
d.line([(50, 250), (370, 250)], fill="black", width=2)
d.text((160, 270), "Load / N", fill="black")
img.save(paper / "images" / "q2_graph.png")
Image.new("RGB", (10, 10), "white").save(paper / "images" / "q4_tiny.png")  # degenerate

# --- extraction.xlsx with deliberate problems ---
wb = openpyxl.Workbook(); ws = wb.active
ws.append(["Question No", "Subject", "Subtopic", "Question text", "Answer", "Image", "Page"])
ws.append(["1", "Physics", "Kinematics",
           "A car accelerates uniformly from rest to 24 m/s in 8.0 s. Calculate the acceleration of the car.",
           "3.0 m/s^2", "", 1])
ws.append(["2", "Physics", "Forces",
           "The diagram shows a spring stretched by a load of 25 N. Determine the extension using the",  # wrong number + truncated
           "", "q2_graph.png", 1])
# Q3 missing entirely -> qno-sequence gap
ws.append(["4", "Physics", "Kinematics",
           "A ball is dropped from a height of 45 m. Taking g = 10 m/s?? calculate the time taken to reach the ground.",  # ?? artifact
           "3.0 s", "q4_tiny.png; q4_missing.png", 2])  # one degenerate, one missing image
ws.append(["5", "Physics", "Kinematics",
           "A car accelerates uniformly from rest to 24 m/s in 8.0 s. Calculate the acceleration of this car.",  # near-duplicate of Q1
           "", "", 2])
wb.save(paper / "extraction.xlsx")
print("demo paper at", paper)
